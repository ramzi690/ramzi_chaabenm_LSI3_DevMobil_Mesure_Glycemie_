package com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.model;

import android.view.View;
import android.widget.Toast;

import com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.view.MainActivity;

public class Patient {
    private int age;
    private float valeurMesuré;
    private boolean jeune;
    private String res;


    //controller --> model


    public Patient(int age, float valeurMesuré, boolean jeune) {
        this.age = age;
        this.valeurMesuré = valeurMesuré;
        this.jeune = jeune;
        calculer();
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getValeurMesuré() {
        return valeurMesuré;
    }

    public void setValeurMesuré(float valeurMesuré) {
        this.valeurMesuré = valeurMesuré;
    }

    public boolean isJeune() {
        return jeune;
    }

    public void setJeune(boolean jeune) {
        this.jeune = jeune;
    }

    public String getRes() {
        return res;
    }


    public  void calculer(){
        if(jeune==true)
            if(age>= 13)
            if(valeurMesuré < 5.0)
                res="le niveau de glycemie est bas";
            else if (valeurMesuré>=5.0  && valeurMesuré<=7.2) {
               res="le niveau de glycemie est normale";
            }
                else
                res="le niveau de glycemie est elevee";
            else if (age >=6 && age<=12)
            if(valeurMesuré<5.0)
                res="niveau glycemie et bas";
            else if (valeurMesuré >=5.0 && valeurMesuré<=10.0 )
                res="niveau glycemie est minimal";
            else
                res="niveau eleve";
        else
        if(valeurMesuré<5.5)
            res="niveau tres bas";
        else if(valeurMesuré>=5.5 && valeurMesuré<=10.0)
            res="niv est minimal";
        else
            res="niveau elevé";
        if (valeurMesuré<=10.5)
            res="niv minimal";
        else
            res="niv eleve";

    }

}

