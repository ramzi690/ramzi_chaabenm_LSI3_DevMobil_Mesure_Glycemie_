package com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.R;

public class ConsultActivity extends AppCompatActivity {
    private TextView tvRep;
    private Button btnRet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consult);
        init();

        Intent intent = getIntent();
        String reponse = intent.getStringExtra("reponse");
        tvRep.setText(reponse);
        btnRet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                if(reponse !=null)
                    setResult(RESULT_OK);
                else
                    setResult(RESULT_CANCELED);
            }
        });
    }
    private void init(){
        tvRep=(TextView) findViewById(R.id.tvReponse);
        btnRet=(Button) findViewById(R.id.btnReturn);
    }
}