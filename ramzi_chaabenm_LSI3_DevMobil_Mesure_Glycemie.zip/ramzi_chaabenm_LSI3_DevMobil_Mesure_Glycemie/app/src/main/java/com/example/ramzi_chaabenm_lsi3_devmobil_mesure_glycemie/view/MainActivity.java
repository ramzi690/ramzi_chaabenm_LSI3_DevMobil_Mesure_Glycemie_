    package com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.view;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.R;
import com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.controller.Controller;

    public class MainActivity extends AppCompatActivity {
    private TextView tvage;
    private SeekBar sbage;
    private RadioButton rbtoui;
    private RadioButton rbtno;
    private EditText etval;
    private Button btnConsulter;

    private final int REQUEST_CODE = 1;
    Controller controller= Controller.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        sbage.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromuser) {
                Log.i("Information","onprogresschange"+progress);
                tvage.setText("Votreâge:"+progress);
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });


    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == REQUEST_CODE)
                if (resultCode == RESULT_CANCELED)
                    Toast.makeText(MainActivity.this,"erreur",Toast.LENGTH_SHORT).show();
        }

        private void init(){
        tvage=(TextView) findViewById(R.id.tvage);
        sbage=(SeekBar) findViewById(R.id.sbage);
        rbtoui=(RadioButton) findViewById(R.id.rbtoui);
        rbtno=(RadioButton) findViewById(R.id.rbtno);
        etval=(EditText) findViewById(R.id.etval);
        btnConsulter=(Button) findViewById(R.id.btnConsulter);
}
    public  void calculer(View v){
            int age;
            float valeurMesuré;
            boolean verifierAge= false;
            boolean verifierValeur=false;
            if(sbage.getProgress()!=0)
                verifierAge=true;
            else
                Toast.makeText(MainActivity.this,"veullier verifier votre age", Toast.LENGTH_SHORT);
            if(etval.getText().toString().isEmpty())
                verifierValeur=true;
            else
                Toast.makeText(MainActivity.this,"vellier verifier votre valeur",Toast.LENGTH_LONG);
            if(verifierAge && verifierValeur){
                age = sbage.getProgress();
                valeurMesuré= Float.valueOf(etval.getText().toString());
                controller.createpatien(age,valeurMesuré,rbtoui.isChecked());


                Intent intent = new Intent(MainActivity.this,ConsultActivity.class);
                intent.putExtra("reponse",controller.getres());
                startActivityForResult(intent,REQUEST_CODE);

            }

        }

}