package com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.controller;

import com.example.ramzi_chaabenm_lsi3_devmobil_mesure_glycemie.model.Patient;

public class Controller {
    private static Controller instance = null;
private static Patient patient;

private Controller() {
    super();
}
public void createpatien(int age,float valeur,boolean jeune){
    patient = new Patient(age,valeur,jeune);
}
public static final Controller getInstance(){
    if(Controller.instance == null)
        Controller.instance=new Controller();
    return Controller.instance;
}
public String getres(){
    return patient.getRes();
}

}
